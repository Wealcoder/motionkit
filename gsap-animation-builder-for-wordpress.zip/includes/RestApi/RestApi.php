<?php

namespace WcfAnimationBuilder\RestApi;

/**
 * REST API Class
 *
 * Registers WP REST API endpoints for MotionKit config operations.
 * Mirrors the existing AJAX handlers in Frontend with proper REST conventions.
 *
 * @package WcfAnimationBuilder
 * @since 1.1.0
 */

// Prevent direct access
if (!defined('ABSPATH')) {
  exit;
}

use WcfAnimationBuilder\Common\AnimationBuilderPageType;
use WcfAnimationBuilder\Auth\JwtTokenManager;
use WcfAnimationBuilder\Support\EditorSessionTrait;

final class RestApi
{
  // Shared editor-connector helpers: verify_server_session(),
  // editor_allowed_origins(), settings_config().
  use EditorSessionTrait;

  /**
   * REST namespace
   */
  private const NAMESPACE = 'motionkit/v1';

  /**
   * Page type resolver
   *
   * @var AnimationBuilderPageType
   */
  private AnimationBuilderPageType $page_type;

  /**
   * Initialize REST API
   *
   * @return void
   */
  public function init(): void
  {
    $this->page_type = AnimationBuilderPageType::instance();
    add_action('rest_api_init', [$this, 'register_routes']);
    // CORS simple requests skip the OPTIONS preflight, but the response
    // still needs Access-Control-Allow-Origin or the browser blocks JS
    // from reading the body. This filter attaches those headers.
    add_filter('rest_pre_serve_request', [$this, 'add_cors_headers'], 10, 4);
  }

  /**
   * Register REST routes
   *
   * @return void
   */
  public function register_routes(): void
  {
    // POST /motionkit/v1/save — CORS-preflight-free endpoint.
    //
    // Accepts "simple requests" (text/plain body, no Authorization header,
    // no X-WP-Nonce) so browsers never send an OPTIONS preflight. Token
    // travels in the JSON body. Single dispatcher for all save/delete/get
    // actions — the old split endpoints remain for same-origin admin use.
    register_rest_route(self::NAMESPACE, '/save', [
      'methods'             => \WP_REST_Server::CREATABLE,
      'callback'            => [$this, 'dispatch_simple'],
      'permission_callback' => '__return_true',
    ]);

    // GET /motionkit/v1/pages — search all animatable pages
    // Permission accepts ?token=<jwt> query param as well as Authorization
    // header, so the editor can GET as a CORS simple request.
    register_rest_route(self::NAMESPACE, '/pages', [
      'methods'             => \WP_REST_Server::READABLE,
      'callback'            => [$this, 'search_pages'],
      'permission_callback' => [$this, 'check_permission_query_token'],
      'args'                => [
        's' => [
          'required'          => false,
          'sanitize_callback' => 'sanitize_text_field',
        ],
        'per_page' => [
          'required'          => false,
          'default'           => 10,
          'sanitize_callback' => 'absint',
        ],
        'page' => [
          'required'          => false,
          'default'           => 1,
          'sanitize_callback' => 'absint',
        ],
      ],
    ]);
  }

  // ─── Permission ─────────────────────────────────────────────────

  /**
   * Permission callback that also accepts ?token=<jwt> in the query string,
   * used by /pages so the editor can GET as a CORS simple request (no
   * Authorization header → no preflight).
   */
  public function check_permission_query_token(\WP_REST_Request $request)
  {
    $token = (string) $request->get_param('token');
    if ($token !== '') {
      if (JwtTokenManager::validate_reusable($token) !== false) {
        return true;
      }
      if ($this->verify_server_session($token)) {
        return true;
      }
    }
    return $this->check_permission($request);
  }

  /**
   * Check if user has permission to access endpoints.
   *
   * Two auth paths:
   * 1. WordPress nonce (X-WP-Nonce header) — logged-in user with manage_options
   * 2. JWT bearer token (Authorization header) — editor session token
   *
   * @param \WP_REST_Request $request
   * @return bool|\WP_Error
   */
  public function check_permission(?\WP_REST_Request $request = null)
  {
    // Public endpoints — authenticated only by JWT bearer token minted
    // when the editor launched this site. No WP login required.
    //
    // Auth precedence:
    //   1. Authorization: Bearer <mk_token> (editor session) → validate.
    //   2. No header but site is connected & has a valid logged-in admin
    //      (same-origin) → allow via cookie.
    //   3. Otherwise → 401.
    $auth_header = '';
    if ($request && $request->get_header('Authorization')) {
      $auth_header = $request->get_header('Authorization');
    } elseif (isset($_SERVER['HTTP_AUTHORIZATION'])) {
      $auth_header = sanitize_text_field(wp_unslash($_SERVER['HTTP_AUTHORIZATION']));
    }

    if (preg_match('/^Bearer\s+(.+)$/i', $auth_header, $matches)) {
      $bearer_token = $matches[1];

      if (JwtTokenManager::validate_reusable($bearer_token) !== false) {
        return true;
      }
      if ($this->verify_server_session($bearer_token)) {
        return true;
      }

      return new \WP_Error(
        'rest_forbidden',
        esc_html__('Invalid or expired token.', 'motionkit'),
        ['status' => 401]
      );
    }

    // Same-origin admin fallback (e.g. built-in wp-admin UI)
    if (is_user_logged_in() && current_user_can('manage_options')) {
      return true;
    }

    return new \WP_Error(
      'rest_forbidden',
      esc_html__('Authentication required.', 'motionkit'),
      ['status' => 401]
    );
  }

  // ─── CORS ──────────────────────────────────────────────────────

  /**
   * Add CORS headers for motionkit REST routes only.
   * Restricts Access-Control-Allow-Origin to known editor origins.
   *
   * @param bool              $served  Whether the request has been served.
   * @param \WP_HTTP_Response $result  Response object.
   * @param \WP_REST_Request  $request Request object.
   * @param \WP_REST_Server   $server  Server instance.
   * @return bool
   */
  public function add_cors_headers($served, $result, $request, $server)
  {
    $route = $request->get_route();

    // Only apply to our namespace
    if (strpos($route, '/' . self::NAMESPACE) !== 0) {
      return $served;
    }

    $origin = isset($_SERVER['HTTP_ORIGIN']) ? sanitize_text_field(wp_unslash($_SERVER['HTTP_ORIGIN'])) : '';

    $allowed_origins = $this->editor_allowed_origins();

    if (!empty($origin) && in_array($origin, $allowed_origins, true)) {
      header('Access-Control-Allow-Origin: ' . $origin);
      header('Vary: Origin');
      header('Access-Control-Allow-Credentials: true');
      header('Access-Control-Allow-Methods: GET, POST, DELETE, OPTIONS');
      header('Access-Control-Allow-Headers: Content-Type, X-WP-Nonce, Authorization');
    }

    return $served;
  }

  // ─── Validators / Helpers ───────────────────────────────────────

  public function validate_json_object($value, $request, $param)
  {
    if (is_array($value) || is_object($value)) {
      return true;
    }
    if (is_string($value)) {
      $decoded = json_decode($value, true);
      if (json_last_error() === JSON_ERROR_NONE && is_array($decoded)) {
        return true;
      }
    }
    return new \WP_Error(
      'rest_invalid_param',
      sprintf(
        /* translators: %s: parameter name */
        esc_html__('%s must be a valid JSON object.', 'motionkit'),
        $param
      ),
      ['status' => 400]
    );
  }

  /**
   * Read the animation folder definitions.
   *
   * Prefers the dedicated motionkit_animation_folders option. Falls back to the
   * legacy location (animationFolders nested inside motionkit_global_settings)
   * for sites saved before folders were split out, so existing folders survive
   * the migration until the next folder save relocates them.
   *
   * @return array
   */
  private function get_animation_folders(): array
  {
    $folders = get_option('motionkit_animation_folders', null);
    if (is_array($folders)) {
      return $folders;
    }
    $global = get_option('motionkit_global_settings', []);
    if (is_array($global) && isset($global['animationFolders']) && is_array($global['animationFolders'])) {
      return $global['animationFolders'];
    }
    return [];
  }

  public function dispatch_simple(\WP_REST_Request $request): \WP_REST_Response
  {
    $raw  = $request->get_body();
    $data = json_decode((string) $raw, true);
    if (!is_array($data)) {
      return new \WP_REST_Response(['success' => false, 'error' => 'invalid_json'], 400);
    }

    $token   = isset($data['token'])   ? (string) $data['token']   : '';
    $action  = isset($data['action'])  ? (string) $data['action']  : '';
    $payload = isset($data['payload']) && is_array($data['payload']) ? $data['payload'] : [];

    if ($token === '' || $action === '') {
      return new \WP_REST_Response(['success' => false, 'error' => 'missing_token_or_action'], 400);
    }

    // Auth: validate JWT body token (same secret as Authorization Bearer).
    if (JwtTokenManager::validate_reusable($token) === false) {
      if (!$this->verify_server_session($token)) {
        return new \WP_REST_Response(['success' => false, 'error' => 'invalid_token'], 401);
      }
    }

    $allowed = [
      'save_global_settings',
      'save_global_animation',
      'save_current_page_settings',
      'save_current_page_animation',
      'save_page_transition_code',
      'save_favourite_cloud_animation',
      'save_animation_folders',
      'delete_global_settings',
      'delete_current_page_settings',
      'get_settings',
    ];
    if (!in_array($action, $allowed, true)) {
      return new \WP_REST_Response(['success' => false, 'error' => 'unknown_action'], 400);
    }

    switch ($action) {
      case 'save_global_settings':
        update_option('motionkit_global_settings', $payload['animationConfigs'] ?? []);
        update_option('motionkit_page_settings_updated_at', time(), true);
        return new \WP_REST_Response(['success' => true, 'data' => ['msg' => 'global_settings_saved']], 200);

      case 'save_global_animation':
        update_option('motionkit_global_animations', $payload['animationConfigs'] ?? []);
        update_option('motionkit_page_settings_updated_at', time(), true);
        return new \WP_REST_Response(['success' => true, 'data' => ['msg' => 'global_animation_saved']], 200);

      case 'save_current_page_animation':
        // Animations live under the original key (default: mkit_pg_animation_<type>)
        $this->page_type->saveConfig(
          $payload['pageTypeConfigs'] ?? [],
          $payload['animationConfigs'] ?? []
        );
        update_option('motionkit_page_settings_updated_at', time(), true);
        return new \WP_REST_Response(['success' => true, 'data' => ['msg' => 'page_animation_saved']], 200);

      case 'save_current_page_settings':
        // Settings live under a distinct key so they don't overwrite animations.
        $this->page_type->saveConfig(
          $this->settings_config($payload['pageTypeConfigs'] ?? []),
          $payload['animationConfigs'] ?? []
        );

        // autoload=true is intentional — Frontend.php reads this on every page
        // load to gate the active-plugin scan. Joining the alloptions cache
        // avoids a per-request SELECT against wp_options.
        update_option('motionkit_page_settings_updated_at', time(), true);

        return new \WP_REST_Response(['success' => true, 'data' => ['msg' => 'page_settings_saved']], 200);

      case 'save_page_transition_code':
        // Persist the exported page-transition code so Frontend.php can
        // inject it on wp_footer. We keep code + preset metadata so the
        // admin can see which preset the current snippet came from.
        $code         = isset($payload['code']) && is_string($payload['code']) ? $payload['code'] : '';
        $preset_key   = isset($payload['presetKey']) ? sanitize_text_field((string) $payload['presetKey']) : '';
        $preset_label = isset($payload['presetLabel']) ? sanitize_text_field((string) $payload['presetLabel']) : '';

        if ($code === '') {
          delete_option('motionkit-page-transition-code');
          return new \WP_REST_Response(['success' => true, 'data' => ['msg' => 'page_transition_cleared']], 200);
        }

        update_option('motionkit-page-transition-code', [
          'code'        => $code,
          'presetKey'   => $preset_key,
          'presetLabel' => $preset_label,
          'updated_at'  => time(),
        ], false);
        return new \WP_REST_Response(['success' => true, 'data' => ['msg' => 'page_transition_saved']], 200);

      case 'save_favourite_cloud_animation':
        // Persist the user's favourited cloud-animation ids. Sanitize each
        // entry to an int (cloud-row ids) and drop anything non-scalar so a
        // malformed payload can't poison the option.
        $favourite = [];
        if (isset($payload['favourite']) && is_array($payload['favourite'])) {
          foreach ($payload['favourite'] as $fav_id) {
            if (is_numeric($fav_id)) {
              $favourite[] = (int) $fav_id;
            } elseif (is_string($fav_id) && $fav_id !== '') {
              $favourite[] = sanitize_text_field($fav_id);
            }
          }
          $favourite = array_values(array_unique($favourite));
        }
        update_option('motionkit_favourite_cloud_animation', $favourite);
        return new \WP_REST_Response(['success' => true, 'data' => ['msg' => 'favourite_cloud_animation_saved']], 200);

      case 'save_animation_folders':
        // Persist the animation folder definitions. Each folder is
        // { folderId, title, pageType }; sanitize each field and drop
        // malformed entries so a bad payload can't poison the option.
        $folders = [];
        if (isset($payload['animationFolders']) && is_array($payload['animationFolders'])) {
          foreach ($payload['animationFolders'] as $folder) {
            if (!is_array($folder)) continue;
            $folder_id = isset($folder['folderId']) ? sanitize_text_field((string) $folder['folderId']) : '';
            if ($folder_id === '') continue;
            $folders[] = [
              'folderId' => $folder_id,
              'title'    => isset($folder['title']) ? sanitize_text_field((string) $folder['title']) : '',
              'pageType' => isset($folder['pageType']) ? sanitize_text_field((string) $folder['pageType']) : '',
            ];
          }
        }
        update_option('motionkit_animation_folders', $folders);
        return new \WP_REST_Response(['success' => true, 'data' => ['msg' => 'animation_folders_saved']], 200);

      case 'delete_global_settings':
        delete_option('motionkit_global_settings');
        return new \WP_REST_Response(['success' => true, 'data' => ['msg' => 'global_settings_deleted']], 200);

      case 'delete_current_page_settings':
        // Delete BOTH the settings key and the animation key so the page is fully cleared.
        $this->page_type->deleteConfig($this->settings_config($payload['pageTypeConfigs'] ?? []));
        $this->page_type->deleteConfig($payload['pageTypeConfigs'] ?? []);
        update_option('motionkit_page_settings_updated_at', time(), true);
        return new \WP_REST_Response(['success' => true, 'data' => ['msg' => 'page_config_deleted']], 200);

      case 'get_settings':
        return new \WP_REST_Response([
          'success' => true,
          'data'    => [
            'globalSettings'  => get_option('motionkit_global_settings', []),
            'globalAnimation' => get_option('motionkit_global_animations', []),
            'favouriteCloudAnimation' => get_option('motionkit_favourite_cloud_animation', []),
            'animationFolders' => $this->get_animation_folders(),
          ],
        ], 200);
    }

    return new \WP_REST_Response(['success' => false, 'error' => 'unreachable'], 500);
  }

  /**
   * Search all animatable pages — posts, pages, CPTs, archives, special pages.
   * Returns URLs with ?action=motionkit-editor appended.
   */
  public function search_pages(\WP_REST_Request $request): \WP_REST_Response
  {
    $search   = strtolower(trim($request->get_param('s') ?? ''));
    $per_page = min((int) $request->get_param('per_page'), 50) ?: 10;
    $page     = max((int) $request->get_param('page'), 1);
    $all      = [];

    // ── 1. Special pages (only on page 1) ──
    if ($page === 1) {
      $special_pages = [
        ['title' => 'Homepage',       'type' => 'front_page', 'url' => home_url('/')],
        ['title' => 'Blog',           'type' => 'blog',       'url' => get_permalink(get_option('page_for_posts')) ?: home_url('/')],
        ['title' => '404 Page',       'type' => '404',        'url' => home_url('/404-preview/')],
        ['title' => 'Search Results', 'type' => 'search',     'url' => home_url('/?s=blog')],
      ];

      foreach ($special_pages as $sp) {
        if (!$search || stripos($sp['title'], $search) !== false || stripos($sp['type'], $search) !== false) {
          $all[] = [
            'id'    => null,
            'title' => $sp['title'],
            'type'  => $sp['type'],
            'group' => 'Special Pages',
            'url'   => $this->editor_url($sp['url']),
          ];
        }
      }
    }

    // ── 2. Singular pages/posts ──
    $post_types = get_post_types(['public' => true], 'objects');

    // Exclude internal/builder post types that aren't real pages
    $excluded_types = [
      'wcf-custom-fonts',
      'attachment',            // Media files
      'elementor_library',     // Elementor templates
      'e-landing-page',        // Elementor landing pages
      'e-floating-buttons',    // Elementor floating buttons
      'oembed_cache',          // oEmbed cache
      'wp_block',              // Reusable blocks
      'wp_template',           // Block theme templates
      'wp_template_part',      // Block theme template parts
      'wp_navigation',         // Navigation menus
      'wp_global_styles',      // Global styles
      'wp_font_family',        // Font families
      'wp_font_face',          // Font faces
      'custom_css',            // Custom CSS
      'customize_changeset',   // Customizer changesets
      'revision',              // Revisions
      'nav_menu_item',         // Menu items
      'user_request',          // Privacy requests
      'fl-builder-template',   // Beaver Builder templates
      'fl-theme-layout',       // Beaver Builder layouts
      'brizy_template',        // Brizy templates
      'ct_template',           // Oxygen Builder templates
      'jet-popup',             // JetPopup
      'jet-menu',              // JetMenu
      'jet-smart-filters',     // JetSmartFilters
      'bricks_template',       // Bricks Builder templates
      'acf-field-group',       // ACF field groups
      'acf-field',             // ACF fields
      'acf-post-type',         // ACF custom post types
      'acf-taxonomy',          // ACF custom taxonomies
      'acf-ui-options-page',   // ACF options pages
      'wpcf7_contact_form',    // Contact Form 7
      'wpforms',               // WPForms
      'wpforms_log',           // WPForms logs
      'frm_display',           // Formidable Forms views
      'wcf-addons-template',   // Animation Addons templates
      'wcf-addons-popup',      // Animation Addons popups
      'wcf-code-snippet',      // Animation Addons code snippets
      'wcf-custom-icons',      // Animation Addons custom icons
      'aaeptypebilder',        // Animation Addons CPT builder
      'aaeaddon_post_rating',  // Animation Addons post ratings
      'metform-form',          // MetForm forms
      'metform-entry',         // MetForm entries
      'wpseo_locations',       // Yoast SEO local locations
      'wpseo_news',            // Yoast SEO news
      'redirect_rule',         // Yoast/RankMath redirects
      'rank_math_schema',      // RankMath schema
      'rm_content_ai',         // RankMath content AI
      'aioseo-template',       // All in One SEO templates
      'et_pb_layout',          // Divi library layouts
      'et_header_layout',      // Divi header templates
      'et_body_layout',        // Divi body templates
      'et_footer_layout',      // Divi footer templates
      'et_code_snippet',       // Divi code snippets
      'et_theme_builder',      // Divi theme builder templates
      'eael_template',         // Essential Addons templates
      'elementskit_template',  // ElementsKit templates
      'elementskit_widget',    // ElementsKit widgets
      'ha_library',            // Happy Addons templates
      'bdthemes-ep-template',  // Element Pack templates
      'uael-template',         // Ultimate Addons for Elementor templates
      'uael_popup',            // Ultimate Addons popups
      'elementor_font',        // Elementor Pro custom fonts
      'elementor_icons',       // Elementor Pro custom icons
      'elementor_snippet',     // Elementor Pro code snippets
      'elementor-thhf',        // Elementor Pro header/footer templates
      'powerpack_templates',   // PowerPack for Elementor templates
      'pp-template',           // PowerPack templates
      'unlimited-template',    // Starter Templates / Starter Sites
    ];

    foreach ($excluded_types as $type) {
      unset($post_types[$type]);
    }

    $query_args = [
      'post_type'      => array_keys($post_types),
      'post_status'    => 'publish',
      'posts_per_page' => $per_page,
      'paged'          => $page,
      'orderby'        => 'title',
      'order'          => 'ASC',
    ];

    if ($search) {
      $query_args['s'] = $search;
    }

    $query = new \WP_Query($query_args);

    foreach ($query->posts as $post) {
      $type_obj = $post_types[$post->post_type] ?? null;
      $all[] = [
        'id'    => $post->ID,
        'title' => $post->post_title ?: '(no title)',
        'type'  => $post->post_type,
        'group' => $type_obj ? $type_obj->labels->singular_name : ucfirst($post->post_type),
        'url'   => $this->editor_url(get_permalink($post)),
      ];
    }

    $total_posts = (int) $query->found_posts;

    // ── 3. Taxonomy terms — show as single archive page per term ──
    if ($page === 1) {
      $taxonomies = get_taxonomies(['public' => true], 'objects');

      foreach ($taxonomies as $tax) {
        // Show only 1 representative term per taxonomy
        $term_args = [
          'taxonomy'   => $tax->name,
          'hide_empty' => false,
          'number'     => 1,
        ];
        if ($search) {
          $term_args['search'] = $search;
          $term_args['number'] = 3; // show more when searching
        }

        $terms = get_terms($term_args);
        if (is_wp_error($terms) || empty($terms)) continue;

        foreach ($terms as $term) {
          $link = get_term_link($term);
          if (is_wp_error($link)) continue;

          $all[] = [
            'id'    => $term->term_id,
            'title' => $term->name,
            'type'  => $tax->name,
            'group' => $tax->labels->singular_name ?: ucfirst($tax->name),
            'url'   => $this->editor_url($link),
          ];
        }
      }

      // ── 4. Author — show single author page ──
      if (!$search || stripos('author', $search) !== false) {
        $authors = get_users([
          'has_published_posts' => true,
          'number'              => 1,
        ]);
        if ($search) {
          $authors = get_users([
            'has_published_posts' => true,
            'search'              => "*{$search}*",
            'search_columns'      => ['display_name'],
            'number'              => 3,
          ]);
        }
        foreach ($authors as $author) {
          $all[] = [
            'id'    => $author->ID,
            'title' => $author->display_name,
            'type'  => 'author',
            'group' => 'Author',
            'url'   => $this->editor_url(get_author_posts_url($author->ID)),
          ];
        }
      }
    }

    $has_more = $total_posts > ($page * $per_page);

    return new \WP_REST_Response([
      'success'  => true,
      'data'     => $all,
      'page'     => $page,
      'per_page' => $per_page,
      'total'    => $total_posts,
      'has_more' => $has_more,
    ], 200);
  }

  /**
   * Append ?action=motionkit-editor to a URL for editor preview.
   */
  private function editor_url(string $url): string
  {
    return add_query_arg('action', 'motionkit-editor', $url);
  }
}
